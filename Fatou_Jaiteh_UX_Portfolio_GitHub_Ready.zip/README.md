# Fatou K. Jaiteh Portfolio

This folder contains a one-page HTML portfolio and downloadable PDF CV.

## Files
- `index.html` — portfolio homepage
- `Fatou_Jaiteh_Mercor_Product_Design_UX_CV.pdf` — downloadable CV

## GitHub Pages Upload Steps
1. Create a new GitHub repository, for example: `fatou-ux-portfolio`
2. Upload both files in this folder to the repository root.
3. Go to Settings > Pages.
4. Under Source, choose `Deploy from a branch`.
5. Select `main` branch and `/root`, then save.
6. Your portfolio will be live at your GitHub Pages URL.
